from .hermenn import Hermadur
from .hermenn import bua_til_hermann
